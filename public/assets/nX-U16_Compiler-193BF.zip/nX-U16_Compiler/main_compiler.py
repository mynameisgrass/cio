# Được làm bởi @kai_1181 và Gemini. Tham khảo một số hàm có trong libcompiler.py của hieuxyz.
# Đây mới chỉ là trình biên dịch thử nghiệm nên vẫn có khả năng xảy ra một số lỗi trong quá trình compile.
# Phiên bản 1.0 (Beta). Cập nhật lần cuối vào 13:32 ngày 29/3/2026

import re
import os
import sys
import subprocess
import time

sys.path.append('Code Source')
from calc_token import CasioToken
try:
    from str_char import char_to_hex
except ImportError:
    char_to_hex = {}
try:
    from address import ADDRESS_TOKENS
except ImportError:
    ADDRESS_TOKENS = {}

class Colors:
    CYAN, YELLOW, GREEN, WHITE = '\033[96m', '\033[93m', '\033[92m', '\033[97m'
    RED, MAGENTA, BLUE, RESET, BOLD = '\033[91m', '\033[95m', '\033[94m', '\033[0m', '\033[1m'

class ROPCompiler:
    def __init__(self):
        self.gadgets = {}
        self.labels_def = {}
        self.blocks = []
        self.block_map = {}
        self.deferred_tasks = []
        self.processed_texts = []
        self.current_block_idx = -1
        self.has_error = False
        self.should_export = False

    def load_source(self, label_path, gadget_path):
        pattern = re.compile(r'^([0-9a-fA-F]+)\s+([^#\n\r]+)')
        for path in [label_path, gadget_path]:
            if not os.path.exists(path): continue
            with open(path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith(('.', '#')): continue
                    match = pattern.match(line)
                    if match:
                        addr = int(match.group(1), 16)
                        name = re.sub(r' *([^a-z0-9]) *', r'\1', match.group(2).lower().strip())
                        self.gadgets[name] = addr

    def log_error(self, msg):
        print(f"{Colors.RED}{Colors.BOLD} ✖ ERROR:{Colors.RESET} {msg}")
        self.has_error = True

    def add_byte(self, b):
        if self.current_block_idx == -1: return
        self.blocks[self.current_block_idx]["bytes"].append(b & 0xFF)

    def emit_3030_val(self, val):
        masked = (val + 0x30300000) & 0xFFFFFFFF
        for i in range(4): self.add_byte((masked >> (i * 8)) & 0xFF)

    def parse_inner_args(self, arg_str):
        if not arg_str: return
        args, temp, depth = [], "", 0
        for char in arg_str:
            if char == '(': depth += 1
            elif char == ')': depth -= 1
            if char == ',' and depth == 0: 
                args.append(temp.strip()); temp = ""
            else: temp += char
        args.append(temp.strip())
        for a in args:
            if not a: continue
            a_low = a.lower().strip()
            clean_a = re.sub(r' *([^a-z0-9]) *', r'\1', a_low)
            p_done = False
            if any(x in a_low for x in ['lbl_address', 'prg_length', 'lbl_length']):
                if 'lbl_address' in a_low:
                    off_m = re.search(r'\[\s*([+-]?\d+)\s*\]', a)
                    offset = int(off_m.group(1)) if off_m else 0
                    name = re.sub(r'lbl_address|!.*?|\[.*?\]|[() ]', '', a, flags=re.I).strip().lower()
                    pos = len(self.blocks[self.current_block_idx]["bytes"])
                    self.add_byte(0); self.add_byte(0)
                    self.deferred_tasks.append(('adr_raw', self.current_block_idx, pos, (name, offset, None)))
                elif 'prg_length' in a_low:
                    m = re.search(r'prg_length\s*\(?\s*([a-zA-Z0-9_]+)?\s*\)?', a, re.I)
                    t_block = m.group(1).lower() if m and m.group(1) else None
                    pos = len(self.blocks[self.current_block_idx]["bytes"])
                    self.add_byte(0); self.add_byte(0)
                    self.deferred_tasks.append(('prg_len_raw', self.current_block_idx, pos, t_block))
                elif 'lbl_length' in a_low:
                    m = re.search(r'lbl_length\s*\(\s*([^,]+)\s*,\s*([^)]+)\s*\)', a, re.I)
                    if m:
                        l1, l2 = m.group(1).strip().lower(), m.group(2).strip().lower()
                        pos = len(self.blocks[self.current_block_idx]["bytes"])
                        self.add_byte(0); self.add_byte(0)
                        self.deferred_tasks.append(('len_raw', self.current_block_idx, pos, (l1, l2)))
                p_done = True
            if not p_done:
                for t_name, addr in ADDRESS_TOKENS.items():
                    if clean_a == re.sub(r' *([^a-z0-9]) *', r'\1', t_name.lower().strip()):
                        self.add_byte(addr & 0xFF); self.add_byte((addr >> 8) & 0xFF)
                        p_done = True; break
            if not p_done and clean_a in self.gadgets:
                self.emit_3030_val(self.gadgets[clean_a]); p_done = True
            if not p_done:
                if a_low.startswith('0x'):
                    val = int(a_low[2:], 16)
                    self.add_byte(val & 0xFF); self.add_byte((val >> 8) & 0xFF)
                elif a_low.startswith('hex '):
                    for x in a[4:].split(): self.add_byte(int(x, 16))
                else: self.log_error(f"Undefined: {a}")

    def process_line(self, line):
        line = line.strip()
        if not line or line.startswith((';', '//')): return
        if '"' in line:
            last_quote = line.rfind('"')
            line = (line[:last_quote+1] + line[last_quote+1:].split('#')[0]).strip()
        else:
            line = line.split('#')[0].strip()
        if not line: return
        line_low = line.lower()
        
        if line_low.startswith('call '):
            addr_m = re.search(r'0x([0-9a-fA-F]+)|([0-9a-fA-F]+)', line[5:])
            if addr_m:
                val_str = addr_m.group(1) if addr_m.group(1) else addr_m.group(2)
                self.emit_3030_val(int(val_str, 16))
                return

        if line_low.startswith('jump'):
            m = re.match(r'^jump\s*\(\s*(.*?)\s*\)$', line, re.I)
            if m:
                self.process_line(f"pop er6(lbl_address({m.group(1).strip()}[-2]))")
                self.process_line("sp = er6, pop er8")
            return
        if '*export_data' in line_low:
            self.should_export = True; return
        if line_low.startswith('set_addr'):
            m = re.search(r'0x([0-9a-fA-F]+)', line)
            if m:
                self.blocks.append({"name": f"block_{len(self.blocks)}", "addr": int(m.group(1), 16), "bytes": [], "export_addr": None})
                self.current_block_idx = len(self.blocks) - 1
            return
        if line_low.startswith('set_block'):
            if self.current_block_idx != -1:
                b_name = line[10:].strip().lower()
                self.blocks[self.current_block_idx]["name"] = b_name
                self.block_map[b_name] = self.current_block_idx
            return
        if line_low.startswith('set_backup_addr'):
            m = re.search(r'0x([0-9a-fA-F]+)', line)
            if m and self.current_block_idx != -1: self.blocks[self.current_block_idx]["export_addr"] = int(m.group(1), 16)
            return
        if line_low.startswith('lbl '):
            name = line[4:].strip().lower()
            pos = len(self.blocks[self.current_block_idx]["bytes"])
            self.labels_def[name] = (self.current_block_idx, pos, self.blocks[self.current_block_idx]["addr"] + pos)
            return
        if line_low.startswith('def '):
            m = re.match(r'^def\s+(.+?)\s*=\s*([0-9a-fA-F]+)$', line, re.I)
            if m:
                n = re.sub(r' *([^a-z0-9]) *', r'\1', m.group(1).lower().strip())
                self.gadgets[n] = int(m.group(2), 16)
            return
        if line_low.startswith('str '):
            match = re.search(r'str\s+"(.*)"', line, re.I)
            if match:
                text = match.group(1); self.processed_texts.append(text)
                for char in text:
                    h = char_to_hex.get(char, '20')
                    if len(h) == 4: self.add_byte(int(h[:2], 16)); self.add_byte(int(h[2:], 16))
                    else: self.add_byte(int(h, 16))
            return

        if line_low.startswith('0x') and not any(x in line for x in [' ', '(', ')', ',']):
            hex_val = line[2:]
            if len(hex_val) % 2 == 0:
                for i in range(len(hex_val)-2, -1, -2): self.add_byte(int(hex_val[i:i+2], 16))
            return

        if line_low.startswith('str_calc '):
            match = re.search(r'str_calc\s+"([^"]*)"', line, re.I)
            if match:
                raw_text = match.group(1)
                if CasioToken:
                    hex_data, err = CasioToken.parse_to_hex(raw_text)
                    if hex_data is not None:
                        for byte in hex_data:
                            self.add_byte(byte)
                        return
                    else:
                        self.log_error(f"Ký tự '{err}' không có trong bảng mã phím Casio!")
                else:
                    self.log_error("Chưa import được module CasioToken!")
            return

        cmd_part, inner = line.strip(), None
        if cmd_part.endswith(')') and '(' in cmd_part:
            depth, split_idx = 0, -1
            for i in range(len(cmd_part)-1, -1, -1):
                if cmd_part[i] == ')': depth += 1
                elif cmd_part[i] == '(': depth -= 1
                if depth == 0: split_idx = i; break
            if split_idx != -1:
                inner = cmd_part[split_idx+1:-1].strip()
                cmd_part = cmd_part[:split_idx].strip()

        line_clean = line.strip()
        if '(' in line_clean and line_clean.endswith(')'):
            first_open = line_clean.find('(')
            last_close = line_clean.rfind(')')
            cmd_part = line_clean[:first_open].strip()
            inner = line_clean[first_open+1:last_close].strip()
        else:
            cmd_part = line_clean
            inner = None

        match_cmd = re.sub(r' *([^a-z0-9]) *', r'\1', cmd_part.lower()).strip()
        processed = False

        if any(x in match_cmd for x in ['lbl_address', 'prg_length', 'lbl_length']):
            self.parse_inner_args(line)
            return

        for t_name, addr in ADDRESS_TOKENS.items():
            if match_cmd == re.sub(r' *([^a-z0-9]) *', r'\1', t_name.lower().strip()):
                self.add_byte(addr & 0xFF); self.add_byte((addr >> 8) & 0xFF)
                if inner: self.parse_inner_args(inner)
                processed = True; break
        
        if not processed and match_cmd in self.gadgets:
            self.emit_3030_val(self.gadgets[match_cmd])
            if inner: self.parse_inner_args(inner)
            processed = True

        if not processed and line_low.startswith('hex '):
            for x in line[4:].split(): self.add_byte(int(x, 16))
            processed = True

        if not processed:
            self.log_error(f"Unknown Command: '{cmd_part}'")

    def finalize(self):
        for task, b_idx, pos, data in self.deferred_tasks:
            target_bytes = self.blocks[b_idx]["bytes"]
            if task == 'adr_raw':
                name, offset, _ = data
                if name in self.labels_def:
                    _, _, l_abs = self.labels_def[name]
                    val = (l_abs + offset) & 0xFFFF
                    target_bytes[pos], target_bytes[pos+1] = val & 0xFF, (val >> 8) & 0xFF
                else: self.log_error(f"Undefined label: {name}")
            elif task == 'prg_len_raw':
                le = len(self.blocks[self.block_map[data]]["bytes"]) if data in self.block_map else len(target_bytes)
                target_bytes[pos], target_bytes[pos+1] = le & 0xFF, (le >> 8) & 0xFF
            elif task == 'len_raw':
                l1, l2 = data
                if l1 in self.labels_def and l2 in self.labels_def:
                    diff = self.labels_def[l2][2] - self.labels_def[l1][2]
                    target_bytes[pos], target_bytes[pos+1] = diff & 0xFF, (diff >> 8) & 0xFF

    def print_result(self):
        if self.labels_def:
            print(f"\n{Colors.CYAN}{Colors.BOLD} [🏷️] LABEL TABLE{Colors.RESET}")
            sep = f" {Colors.YELLOW}┌{'─'*22}┬{'─'*14}┬{'─'*12}┐{Colors.RESET}"
            div = f" {Colors.YELLOW}├{'─'*22}┼{'─'*14}┼{'─'*12}┤{Colors.RESET}"
            foot = f" {Colors.YELLOW}└{'─'*22}┴{'─'*14}┴{'─'*12}┘{Colors.RESET}"
            print(sep)
            print(f" {Colors.YELLOW}│ {Colors.WHITE}{'LABEL NAME':<20} {Colors.YELLOW}│ {Colors.WHITE}{'BLOCK':<12} {Colors.YELLOW}│ {Colors.WHITE}{'ADDRESS':<10} {Colors.YELLOW}│{Colors.RESET}")
            print(div)
            for name, (b_idx, pos, addr) in sorted(self.labels_def.items()):
                b_name = self.blocks[b_idx]["name"]
                addr_str = f"0x{addr:04X}"
                print(f" {Colors.YELLOW}│ {Colors.WHITE}{name:<20} {Colors.YELLOW}│ {Colors.CYAN}{b_name:<12} {Colors.YELLOW}│ {Colors.GREEN}{addr_str:<10} {Colors.YELLOW}│{Colors.RESET}")
            print(foot)

        if self.processed_texts:
            print(f"\n{Colors.GREEN}{Colors.BOLD} [📝] TEXT TABLE{Colors.RESET}")
            for text in self.processed_texts:
                print(f" {Colors.WHITE} Processing text: {Colors.CYAN}\"{text}\"{Colors.RESET}")

        w_n, w_a, w_s = 18, 12, 14
        sep_b = f" {Colors.YELLOW}┌{'─'*(w_n)}┬{'─'*(w_a)}┬{'─'*(w_s)}┐{Colors.RESET}"
        div_b = f" {Colors.YELLOW}├{'─'*(w_n)}┼{'─'*(w_a)}┼{'─'*(w_s)}┤{Colors.RESET}"
        foot_b = f" {Colors.YELLOW}└{'─'*(w_n)}┴{'─'*(w_a)}┴{'─'*(w_s)}┘{Colors.RESET}"
        print(f"\n{Colors.GREEN}{Colors.BOLD} [💽] BLOCK TABLE{Colors.RESET}")
        print(f"{sep_b}")
        print(f" {Colors.YELLOW}│ {Colors.WHITE}{'BLOCK NAME':<{w_n-2}} {Colors.YELLOW}│ {Colors.WHITE}{'ADDRESS':<{w_a-2}} {Colors.YELLOW}│ {Colors.WHITE}{'SIZE':<{w_s-2}} {Colors.YELLOW}│{Colors.RESET}")
        print(div_b)
        total_size = 0
        for b in self.blocks:
            addr_val = b["export_addr"] if b["export_addr"] is not None else b["addr"]
            addr_str = f"0x{addr_val:04X}"
            size_str = f"{len(b['bytes'])} bytes"
            total_size += len(b['bytes'])
            print(f" {Colors.YELLOW}│ {Colors.CYAN}{b['name']:<{w_n-2}} {Colors.YELLOW}│ {Colors.GREEN}{addr_str:<{w_a-2}} {Colors.YELLOW}│ {Colors.WHITE}{size_str:<{w_s-2}} {Colors.YELLOW}│{Colors.RESET}")
        print(foot_b)
        print(f" {Colors.MAGENTA}Σ Total Payload: {Colors.BOLD}{total_size} bytes{Colors.RESET}")

        for b in self.blocks:
            base_addr = b["export_addr"] if b["export_addr"] is not None else b["addr"]
            print(f"\n{Colors.MAGENTA}{Colors.BOLD} ● Block: {b['name'].upper()} {Colors.RESET}─ 0x{base_addr:04X}")
            header_hex = " ".join(f"{i:02X}" for i in range(16))
            sep_h = f" {Colors.YELLOW}┌{'─'*9}┬{'─'*49}┐{Colors.RESET}"
            head_h = f" {Colors.YELLOW}│ {Colors.CYAN}ADDRESS {Colors.YELLOW}│ {Colors.BLUE}{header_hex} {Colors.YELLOW}│{Colors.RESET}"
            div_h = f" {Colors.YELLOW}├{'─'*9}┼{'─'*49}┤{Colors.RESET}"
            split_h = f" {Colors.YELLOW}├{'╶'*9}┼{'╶'*49}┤{Colors.RESET}"
            foot_h = f" {Colors.YELLOW}└{'─'*9}┴{'─'*49}┘{Colors.RESET}"
            print(sep_h)
            print(head_h)
            print(div_h)
            data = b['bytes']
            line_count = 0
            for i in range(0, len(data), 16):
                if line_count > 0 and line_count % 6 == 0:
                    print(split_h)
                chunk = data[i:i+16]
                hex_str = " ".join(f"{x:02X}" for x in chunk)
                hex_display = f"{hex_str:<47}" 
                addr_line = f"{base_addr + i:04X}"
                print(f" {Colors.YELLOW}│  {Colors.WHITE}{addr_line:<5}  {Colors.YELLOW}│ {Colors.GREEN}{hex_display} {Colors.YELLOW}│{Colors.RESET}")
                line_count += 1
            print(foot_h)

    def generate_export(self, file_name):
        if not self.should_export: return
        var_name = os.path.splitext(file_name)[0]
        
        temp_path = os.path.expanduser("~/hc-inj_temp.txt")
        final_path = "/storage/emulated/0/Android/data/com.tele.u8emulator/files/hc-inj.txt"

        try:
            with open(temp_path, "w", encoding="utf-8") as f:
                f.write(f"# nX-U16 Export: {file_name}\n")
                f.write(f"{var_name} = {{\n")
                
                for i, b in enumerate(self.blocks):
                    addr = b["export_addr"] if b["export_addr"] is not None else b["addr"]
                    hex_data = " ".join(f"{x:02X}" for x in b['bytes'])
                    comma = "," if i < len(self.blocks) - 1 else ""
                    
                    f.write(f"    0x{addr:04X} = \"{hex_data}\"{comma}\n")
                f.write("}\n\n") 
                f.flush()
                os.fsync(f.fileno())

            print(f"{Colors.CYAN} [📠] Exporting...{Colors.RESET}")
            subprocess.run(["adb", "shell", "mkdir", "-p", os.path.dirname(final_path)], capture_output=True)
            
            cmd = ["adb", "push", temp_path, final_path]
            result = subprocess.run(cmd, capture_output=True, text=True)

            if result.returncode == 0:
                print(f"{Colors.GREEN} [✔] Export Successful! {Colors.RESET}")
            else:
                print(f"{Colors.RED} [✘] ADB Error: {result.stderr.strip()}{Colors.RESET}")

        except Exception as e:
            print(f"{Colors.RED} [!] Critical Error: {str(e)}{Colors.RESET}")

    def compile(self, file_path):
        self.blocks, self.labels_def, self.deferred_tasks, self.processed_texts, self.has_error, self.block_map = [], {}, [], [], False, {}
        self.current_block_idx = -1
        self.should_export = False
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                for line in f: self.process_line(line)
            self.finalize()
            if not self.has_error:
                self.print_result()
                self.generate_export(os.path.basename(file_path))
        except Exception as e: self.log_error(str(e))
