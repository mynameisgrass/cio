import re

class CasioToken:
    # --- BẢNG MÃ OPCODE (CASIO PHÍM BẤM) ---
    OPCODES = {
        # Numbers 0 -> 9
        "0": 0x30, "1": 0x31, "2": 0x32, "3": 0x33, "4": 0x34,
        "5": 0x35, "6": 0x36, "7": 0x37, "8": 0x38, "9": 0x39,
        
        # Functions 77 -> 7C
        "sin(": 0x77, "cos(": 0x78, "tan(": 0x79, 
        "asin(": 0x7A, "acos(": 0x7B, "atan(": 0x7C,
        
        # Math Functions
        "abs(": 0x68, "ranint#(": 0x87, "int(": 0x83,
        "gcd(": 0x88, "lcm(": 0x89, "sqrt(": 0x74, "√(": 0x74,
        
        # Operators 60, D0, A6 -> A9, D5, D6, C9, C8
        "(": 0x60, ")": 0xD0, 
        "+": 0xA6, "-": 0xA7, "×": 0xA8, "*": 0xA8, "÷": 0xA9, 
        "²": 0xD5, "³": 0xD6, "^(": 0xC9, "/": 0xC8,
        
        # Variables & Ans 40 -> 4A
        "ans": 0x40, "m": 0x41, "a": 0x42, "b": 0x43, "c": 0x44,
        "d": 0x45, "e": 0x46, "f": 0x47, "x": 0x48, "y": 0x49, "z": 0x4A,
        
        # Null
        "_": 0x00
    }

    @classmethod
    def parse_to_hex(cls, text):
        """Chuyển chuỗi text sang list byte hex"""
        res = []
        # Sort keys theo độ dài giảm dần để ưu tiên khớp cụm từ dài (như asin)
        sorted_keys = sorted(cls.OPCODES.keys(), key=len, reverse=True)
        
        content = text.lower().replace(" ", "") # Xóa space, đưa về thường
        i = 0
        while i < len(content):
            found = False
            for key in sorted_keys:
                if content.startswith(key, i):
                    res.append(cls.OPCODES[key])
                    i += len(key)
                    found = True
                    break
            if not found:
                return None, content[i] # Trả về ký tự lỗi nếu không khớp
        return res, None
