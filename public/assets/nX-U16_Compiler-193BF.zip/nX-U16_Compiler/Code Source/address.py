ADDRESS_TOKENS = {
    # Keyboard & Input
    "adrcvtkey": 0x083DA,
    "unstable_char": 0x0D318,
    "input_range": 0x0D180,

    # Registers & System Vars
    "reg0": 0x0D000,
    "reg0.9": 0x0D009,
    "modifiers": 0x0D110,
    "mode": 0x0D111,
    "submode": 0x0D112,
    "num_format": 0x0D11A,
    "num_format_i": 0x0D11B,
    "angle_unit": 0x0D11D,
    "magic_string": 0x0DBD0,

    # UI & Display
    "draw_mode": 0x0D138,
    "current_screen_buffer": 0x0D139,
    "screen_buffer": 0x0DDD4,
    "font_size": 0x0D137,
    "cursor_noflash": 0x0D113,

    # Variables (Memory RAM)
    "var_m": 0x0D31A,
    "var_ans": 0x0D324,
    "var_a": 0x0D32E,
    "var_b": 0x0D338,
    "var_c": 0x0D342,
    "var_d": 0x0D34C,
    "var_e": 0x0D356,
    "var_f": 0x0D360,
    "var_x": 0x0D36A,
    "var_y": 0x0D374,
    "var_preans": 0x0D37E,
    "var_z": 0x0D388,
    "calc_history": 0x0D392
}
