def memcpy_auto_jump = 2b2ba
def num_to_hex = 1ed58
def black_pixel_draw = 091ea
def pop xr4, xr12 = 2045c

set_addr 0xd730
set_backup_addr 0xe9e0
set_block data

    lbl rotating_calc
        pop xr0 (lbl_address addr_inc_degree, var_c)
        calc_func
        pop xr0 (lbl_address addr_rotated_x, var_a)
        calc_func
        pop xr0 (lbl_address addr_rotated_y, var_b)
        calc_func
        pop xr0 (lbl_address addr_total, var_m)
        calc_func
            
    lbl draw
        pop er0 (var_m)
        num_to_hex
        setlr_pc
        di,rt
        black_pixel_draw
        render.ddd4
        
    lbl loop
        pop xr4, xr12 (lbl_address rotating_calc, prg_length (data), lbl_address [+4784] (rotating_calc), lbl_address [-12] rotating_calc)
        memcpy_auto_jump
        
    lbl addr_inc_degree
        lbl_address inc_degree
    
    lbl addr_rotated_x
        lbl_address rotated_x
    
    lbl addr_rotated_y
        lbl_address rotated_y
        
    lbl addr_total
        lbl_address total
        
    lbl inc_degree
        str_calc "C+2_"
        
    lbl rotated_x
        str_calc "24sin(C)+96_"
        
    lbl rotated_y
        str_calc "-24cos(C)+32_"
    
    lbl total
        str_calc "256Int(B)+Int(A)_"
        
set_addr 0xd180
set_block launcher

    lbl launcher
        hex fd 20
        lbl_address rotating_calc
        hex fe 01
        hex 30 30 30 30
        lbl_address [+4784] rotating_calc
        lbl_address [-12] rotating_calc
        setlr_pc
        setsfr
        memcpy_auto_jump
        
*export_data