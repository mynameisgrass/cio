def memcpy_auto_jump = 2b2ba
def smart_line_print = 099c6

set_addr 0xd730
set_backup_addr 0xe9e0
set_block data

    lbl home
        pop xr0 (lbl_address [+4784] (text), hex 04 00)
        smart_line_print
    
    lbl scroll
        pop er2 (hex 01 01)
        pop er8 (hex 39 f0)
        [er8]+=er2,pop xr8 (hex 00 00 00 00)
    
    lbl loop
        pop er0 (hex 00 02)
        delay
        jump (scroll)
    
    lbl text
        str "Tôi như con kiến"
        0x00
        str "Giữa~thủ~đô~vội~vàng"
        0x00
        str "1000 năm văn hiến"
        0x00
        str "1000 năm yêu nàng"
        0x00
        
set_addr 0xd180
set_block launcher

    lbl launcher
        hex fd 20
        lbl_address (home)
        hex fe 01
        hex 30 30 30 30
        lbl_address [+4784] (home)
        lbl_address [-12] (home)
        setlr
        setsfr
        memcpy_auto_jump
        
*export_data