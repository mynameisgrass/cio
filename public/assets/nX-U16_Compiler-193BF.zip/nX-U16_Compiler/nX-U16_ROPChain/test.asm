def test = 33030

set_addr 0xd730
set_block test

    lbl test
        lbl_length (test, end)
        call 308d0
        nop (0x0000, lbl_address test, var_a)
        var_b
    
    lbl end
        test
        str "Hello world"
        str_calc "1+1_"