def memcpy_auto_jump = 2b2ba
def draw_black_pixel = 091ea
def draw_white_pixel = 091e6
def pop xr4, xr12 = 2045c

set_addr 0xd730
set_backup_addr 0xe9e0
set_block data

    lbl home
        getkeycode
        setlr_pc
        pop ea (lbl_address table)
        ea_switchcase
        qr0=[ea],lea D002H,[ea]=qr0
        er8 = er0
        [er8]+=er2, pop xr8 (hex 00 00 00 00)
    
    lbl coord
        [er4]=er0,pop er0,rt (hex 00 00)
        
    lbl function
        nop
        
    lbl loop
        render.ddd4
        pop xr4, xr12 (lbl_address home, prg_length (data), lbl_address [+4784] (home), lbl_address [-12] home)
        memcpy_auto_jump
        
    lbl table
        hex 32 00
        draw_white_pixel
        lbl_address (function)
        
        hex 31 00
        draw_black_pixel
        lbl_address (function)
        
        hex 26 fc
        buffer_clear
        lbl_address (function)
        
        hex 1c fc
        lbl_address [+4788] (coord)
        hex 00 ff
        
        hex 1d fc
        lbl_address [+4788] (coord)
        hex 00 01
        
        hex 1e fc
        lbl_address [+4788] (coord)
        hex 01 00
        
        hex 1f fc
        lbl_address [+4788] (coord)
        hex ff ff
        
        hex 00 00
        
set_addr 0xd180
set_block launcher

    lbl launcher
        hex fd 20
        lbl_address (home)
        hex fe 01
        hex 30 30 30 30
        lbl_address [+4784] (home)
        lbl_address [-12] (home)
        setlr_pc
        setsfr
        pop xr0 (hex 31 30 f5 d0)
        [er2]=r0, r2 = 0
        memcpy_auto_jump
        
*export_data