def memcpy_auto_jump = 2b2ba
def calc_mode = 2e236
def num_to_hex = 1ed58
def check_one_key = 0d390

set_addr 0xd730
set_backup_addr 0xe9e0
set_block data

    lbl setup_input
        calc_mode
        pop xr0 (var_d, 0x000a)
        memzero
        buffer_clear (hex 08 00)
        pop er0 (hex 37 d1)
        [er0]=r2
        pop xr0 (hex 61 01 11 00)
        char_print
        pop xr0 (hex b8 18 10 00)
        char_print
        pop xr0 (hex 58 22 30 00)
        char_print
        pop xr0 (hex 60 40 60 00)
        line_draw
        pop xr0 (hex 00 20 c0 20)
        line_draw
        pop xr0 (lbl_address total, 0x0044)
        [er0]=r2
    
    lbl calc_setup
        pop xr0 (var_y, var_c)
        setlr_pc
        num_cpy
        pop xr0 (lbl_address addr_def_val, var_x)
        calc_func
        pop xr0 (lbl_address addr_input, var_c)
        calc_func
        pop xr0 (lbl_address addr_inc_val, var_d)
        calc_func
        pop xr0 (lbl_address addr_def_range_x, var_d)
        calc_func
        pop xr0 (lbl_address addr_result, var_c)
        calc_func
        pop xr0 (lbl_address addr_def_range_y, var_c)
        calc_func
        pop xr0 (lbl_address addr_xy_pos, var_c)
        calc_func
        pop xr0 (lbl_address addr_total, 0xd3a0)
        calc_func
        render.ddd4
    
    lbl key_processing
        pop xr0 (lbl_address [+4790] key_processing, hex 04 10)
        check_one_key
        setlr_pc
        di,rt
        er2 = er0,er0+=er4,rt
        pop er0, er4 (lbl_address [-62] draw, lbl_length (draw,cancel))
        er4*=r2,er4+=er0,r8=r8,rt
        sp = er4,sp+=32,pop xr4,pop qr8
        
    lbl draw
        pop er0 (0xd3a0)
        num_to_hex
        BL line_draw
        pop xr4, qr8
        
    lbl cancel
        pop xr0 (lbl_address [+10] loop, lbl_address [-12] setup_input)
        [er0]=er2,rt
        
    lbl clear_status
        pop xr0 (screen_buffer, 0x0016)
        memzero
        
    lbl loop
        pop xr4, xr12 (lbl_address setup_input, prg_length (data), lbl_address [+4784] setup_input, lbl_address [-12] calc_setup)
        memcpy_auto_jump
        
    lbl addr_def_val
        lbl_address def_val
    
    lbl addr_input
        input_range
        
    lbl addr_inc_val
        lbl_address inc_val
        
    lbl addr_def_range_x
        lbl_address def_range_x
        
    lbl addr_result
        lbl_address result
    
    lbl addr_def_range_y
        lbl_address def_range_y
        
    lbl addr_xy_pos
        lbl_address xy_pos
        
    lbl addr_total
        lbl_address total
        
    lbl def_val
        str_calc "D×A÷96-A_"
        
    lbl inc_val
        str_calc "D+1_"
        
    lbl def_range_x
        str_calc "(D+192-Abs(D-192))÷2_"
        
    lbl result
        str_calc "Int(32-C÷B×32)_"
        
    lbl def_range_y
        str_calc "(Abs(C)-Abs(64-C)+64)÷2_"
        
    lbl xy_pos
        str_calc "256C+D_"
        
    lbl total
        str_calc "65536C+y_"
        
set_addr 0xd180
set_block launcher
    
    lbl launcher
        hex fd 20
        lbl_address setup_input
        prg_length (data)
        hex 30 30 30 30
        lbl_address [+4784] setup_input
        lbl_address [-12] setup_input
        memcpy_auto_jump
        
*export_data