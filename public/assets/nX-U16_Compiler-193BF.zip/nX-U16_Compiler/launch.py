# Được làm bởi @kai_1181 và Gemini. Tham khảo một số hàm có trong libcompiler.py của hieuxyz.
# Đây mới chỉ là trình biên dịch thử nghiệm nên vẫn có khả năng xảy ra một số lỗi trong quá trình compile.
# Phiên bản 1.0 (Beta). Cập nhật lần cuối vào 13:32 ngày 29/3/2026

import os, time, sys, re, subprocess
from main_compiler import ROPCompiler, Colors

def get_clean_len(text):
    """Tính độ dài thực, bù trừ cho các ký tự Unicode rộng"""
    clean_text = re.sub(r'\033\[[0-9;]*m', '', str(text))
    length = 0
    for char in clean_text:
        if ord(char) > 255: length += 2 
        else: length += 1
    return length

def draw_row(content, width, border_color=Colors.CYAN, border_char='║'):
    """Vẽ dòng với cơ chế bù khoảng trắng chính xác"""
    c_len = get_clean_len(content)
    space_needed = width - c_len
    left_pad = space_needed // 2
    right_pad = space_needed - left_pad
    return f" {border_color}{border_char}{' ' * left_pad}{content}{' ' * right_pad}{border_char}{Colors.RESET}"

def print_banner():
    """Banner nX-U16: Tối giản hóa để tránh lỗi hiển thị"""
    print(f"{Colors.CYAN}")
    lines = [
        "███╗   ██╗██╗  ██╗      ██╗   ██╗ ██╗ ██████╗",
        "████╗  ██║╚██╗██╔╝      ██║   ██║███║██╔════╝",
        "██╔██╗ ██║ ╚███╔╝ █████╗██║   ██║╚██║███████╗",
        "██║╚██╗██║ ██╔██╗ ╚════╝██║   ██║ ██║██╔═══██╗",
        "██║ ╚████║██╔╝ ██╗      ╚██████╔╝ ██║╚██████╔╝",
        "╚═╝  ╚═══╝╚═╝  ╚═╝       ╚═════╝  ╚═╝ ╚═════╝"
    ]
    for line in lines:
        print(line.center(60))
    print(f"{Colors.WHITE}{Colors.BOLD}{'n X - U 1 6   C O M P I L E R'.center(60)}{Colors.RESET}\n")

def print_dashboard(rop_dir, compiler):
    asm_count = len([f for f in os.listdir(rop_dir) if f.endswith('.asm')]) if os.path.exists(rop_dir) else 0
    tw = 55
    
    print(f" {Colors.CYAN}╔{'═'*tw}╗")
    credit = f"Develop by @Kai_1811 and Gemini"
    info = f"{credit} | FILES: {asm_count}"

    print(draw_row(info, tw))
    
    print(f" {Colors.CYAN}╚{'═'*tw}╝{Colors.RESET}")

    
def show_source_file(filename, title, color):
    """Đọc và hiển thị nội dung file nguồn không giới hạn dòng, chống lệch tuyệt đối"""
    src_dir = "Code Source"
    path = os.path.join(src_dir, filename)
    tw = 65 
    
    if not os.path.exists(path):
        print(f"\n {Colors.RED} ✖ Error: {filename} không tồn tại trong {src_dir}{Colors.RESET}")
        time.sleep(1.5)
        return

    with open(path, 'r', encoding='utf-8') as f:
        lines = [l.rstrip() for l in f.readlines()]

    print(f"\n {color}╔{'═'*tw}╗")
    t_pad = (tw - len(title)) // 2
    print(f" {color}║{' '*t_pad}{Colors.WHITE}{Colors.BOLD}{title}{' '*(tw - t_pad - len(title))}{color}║")
    print(f" {color}╠{'═'*tw}╣{Colors.RESET}")

    if not lines:
        print(f" {color}║ {Colors.YELLOW}{'[ FILE TRỐNG ]':<63} {color}║")
    else:
        for line in lines:
            content = line.replace('\t', '    ')
            
            if len(content) > 61:
                content = content[:58] + "..."
            
            padding = max(0, tw - len(content) - 2)
            
            print(f" {color}║ {Colors.WHITE}{content}{' ' * padding} {color}║")

    print(f" {color}╚{'═'*tw}╝{Colors.RESET}")
    
    total = len(lines)
    print(f" {Colors.CYAN} Tổng cộng: {Colors.WHITE}{total} dòng đã nạp.{Colors.RESET}")
    input(f"\n {Colors.MAGENTA} ❯ Nhấn Enter để quay lại Menu...{Colors.RESET}")
    
def check_files(filename):
    """Hiển thị nội dung của một file cụ thể với khung chống lệch"""
    search_dirs = ["Code Source", "nX-U16_ROPChain"]
    target_path = None
    
    for d in search_dirs:
        p = os.path.join(d, filename)
        if os.path.exists(p):
            target_path = p
            break
            
    if not target_path:
        print(f" {Colors.RED} ✖ Error: Không tìm thấy file '{filename}'{Colors.RESET}")
        time.sleep(1)
        return

    tw = 65
    title = f" CONTENT: {filename.upper()} "
    color = Colors.CYAN
    
    print(f"\n {color}╔{'═'*tw}╗")
    t_pad = (tw - len(title)) // 2
    print(f" {color}║{' '*t_pad}{Colors.WHITE}{Colors.BOLD}{title}{' '*(tw - t_pad - len(title))}{color}║")
    print(f" {color}╠{'═'*tw}╣{Colors.RESET}")

    with open(target_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        for line in lines:
            content = line.replace('\t', '    ').rstrip()
            if len(content) > 61: content = content[:58] + "..."
            
            padding = max(0, tw - len(content) - 2)
            print(f" {color}║ {Colors.WHITE}{content}{' ' * padding} {color}║")

    print(f" {color}╚{'═'*tw}╝{Colors.RESET}")
    print(f" {Colors.YELLOW} Tổng cộng: {len(lines)} dòng.{Colors.RESET}")
    input(f"\n {Colors.MAGENTA} ❯ Nhấn Enter để tiếp tục...{Colors.RESET}")


def list_files(directory):
    if not os.path.exists(directory): 
        if not os.path.exists(directory): os.makedirs(directory)
        return
        
    files = sorted([f for f in os.listdir(directory) if f.endswith('.asm')])
    tw = 55
    
    print(f" {Colors.CYAN}┌{'─'*tw}┐{Colors.RESET}")
    title = "SOURCE REPOSITORY"
    t_pad = (tw - len(title)) // 2
    print(f" {Colors.CYAN}│{' '*t_pad}{Colors.WHITE}{Colors.BOLD}{title}{' '*(tw - t_pad - len(title))}{Colors.CYAN}│{Colors.RESET}")
    print(f" {Colors.CYAN}├{'─'*tw}┤{Colors.RESET}")
    
    if not files:
        empty_msg = "[ EMPTY REPOSITORY ]"
        e_pad = (tw - len(empty_msg)) // 2
        print(f" {Colors.CYAN}│{' '*e_pad}{Colors.RED}{empty_msg}{' '*(tw - e_pad - len(empty_msg))}{Colors.CYAN}│{Colors.RESET}")
    else:
        for f in files:
            display_name = (f[:42] + "...") if len(f) > 45 else f
            raw_content = f"  {display_name}" 
            padding_size = tw - len(raw_content)
            print(f" {Colors.CYAN}│{Colors.GREEN}{raw_content}{' '*padding_size}{Colors.CYAN}│{Colors.RESET}")
    print(f" {Colors.CYAN}└{'─'*tw}┘{Colors.RESET}")

def show_help():
    tw = 74
    def draw_row(content, color=Colors.WHITE, symbol="│"):
        clean_c = re.sub(r'\033\[[0-9;]*m', '', content)
        padding = tw - len(clean_c) - 4
        return f"{Colors.YELLOW}{symbol} {color}{content}{' ' * padding} {Colors.YELLOW}{symbol}{Colors.RESET}"

    rows = []
    rows.append(f"{Colors.YELLOW}╭{'─'*(tw-2)}╮{Colors.RESET}")
    rows.append(f"{Colors.YELLOW}│{Colors.MAGENTA}{Colors.BOLD} {'[ nX-U16 ROP COMPILER - SYSTEM INTERFACE ]':^{tw-4}} {Colors.YELLOW}│{Colors.RESET}")
    rows.append(f"{Colors.YELLOW}├{'─'*(tw-2)}┤{Colors.RESET}")
    
    rows.append(draw_row(f"{Colors.WHITE}{Colors.BOLD}[#] COMMAND LINE INTERFACE", Colors.WHITE))
    rows.append(f"{Colors.YELLOW}│{' '*(tw-2)}│{Colors.RESET}")
    
    ui_data = [
        ("auto-comp", "Watch & auto-build .asm changes"),
        ("check_gadgets", "List all gadgets from gadgets.txt"),
        ("check_labels", "List all defined labels"),
        ("check_files", "Preview file content (ex: check_files a.asm)"),
        ("help", "Show this pro-interface menu"),
        ("brk / exit", "Terminate nX-U16 session")
    ]
    
    for cmd, desc in ui_data:
        c_v = get_clean_len(cmd)
        line = f"{Colors.GREEN}>> {cmd}{' '*(18-c_v)}{Colors.CYAN}--> {Colors.WHITE}{desc}"
        rows.append(draw_row(line))

    rows.append(f"{Colors.YELLOW}├{'─'*(tw-2)}┤{Colors.RESET}")
    rows.append(draw_row(f"{Colors.WHITE}{Colors.BOLD}[$] ROP SYNTAX & COMPILER MACROS", Colors.WHITE))
    rows.append(f"{Colors.YELLOW}│{' '*(tw-2)}│{Colors.RESET}")
    
    syntax_data = [
        ("set_addr 0x..", "Set base address for data block"),
        ("set_block name", "Define block identifier"),
        ("call 0x..", "Call function (Auto LE conversion)"),
        ("0x<hex_val>", "Insert byte-reversed hex data"),
        ("str \"text\"", "Insert string (Auto-encoded)"),
        ("str_calc \"(t)\"", "Insert Casio calculation tokens"),
        ("lbl NAME", "Define label at current position"),
        ("jump(label)", "Set SP to label[-2] address"),
        ("lbl_addr(n)", "Get 2-byte label address"),
        ("lbl_len(a,b)", "Calculate offset between a and b"),
        ("prg_len(n)", "Get total size of block n"),
        ("*export_data", "Push to hc-inj.txt (ADB Mode)")
    ]
    
    for cmd, desc in syntax_data:
        c_v = get_clean_len(cmd)
        line = f"{Colors.MAGENTA}>> {cmd}{' '*(20-c_v)}{Colors.YELLOW}--> {Colors.WHITE}{desc}"
        rows.append(draw_row(line))
    
    rows.append(f"{Colors.YELLOW}╰{'─'*(tw-2)}╯{Colors.RESET}")

    print("")
    for r in rows:
        print(r)
        time.sleep(0.012)

    print(f"\n {Colors.WHITE}{Colors.BOLD} ❯ Nhấn {Colors.GREEN}Enter{Colors.WHITE} để quay lại Menu...{Colors.RESET}", end="")
    input()

def refresh_ui(rop_dir, compiler):
    os.system('cls' if os.name == 'nt' else 'clear')
    print_banner()
    print_dashboard(rop_dir, compiler)
    list_files(rop_dir)
    print()

def main():
    compiler = ROPCompiler()
    src_dir, rop_dir = "Code Source", "nX-U16_ROPChain"
    if not os.path.exists(rop_dir): os.makedirs(rop_dir)
    
    try:
        lp, gp = os.path.join(src_dir, "labels.txt"), os.path.join(src_dir, "gadgets.txt")
        if os.path.exists(lp) and os.path.exists(gp): compiler.load_source(lp, gp)
    except: pass

    while True:
        refresh_ui(rop_dir, compiler)
        tw = 55
        prompt_text = f"CMD: 'connect <IP>' | 'help' | 'brk'"
        print(f" {Colors.MAGENTA}╔{'═'*tw}╗")
        print(draw_row(prompt_text, tw, border_color=Colors.MAGENTA))
        print(f" {Colors.MAGENTA}╚{'═'*tw}╝{Colors.RESET}")
        
        try:
            cmd = input(f" {Colors.BOLD}{Colors.GREEN}nX-U16 {Colors.WHITE}❯ {Colors.RESET}").strip()
        except EOFError: break
        
        if not cmd: continue
        cmd_lower = cmd.lower()
        
        if cmd_lower in ['brk', 'exit']: break
        if cmd_lower == 'help': show_help(); continue

        if cmd_lower.startswith('connect '):
            ip = cmd[8:].strip()
            if ip:
                print(f" {Colors.CYAN} [⚡] Connecting to {ip}...{Colors.RESET}")
                try:
                    res = subprocess.run(["adb", "connect", ip], capture_output=True, text=True)
                    if "connected" in res.stdout.lower():
                        print(f" {Colors.GREEN} [✔] {res.stdout.strip()}{Colors.RESET}")
                    else:
                        print(f" {Colors.RED} [✘] {res.stdout.strip()}{Colors.RESET}")
                except Exception as e:
                    print(f" {Colors.RED} [!] Error: {str(e)}{Colors.RESET}")
            else:
                print(f" {Colors.RED} ✖ Thiếu IP! VD: connect 192.168.1.5{Colors.RESET}")
            time.sleep(1.5)
            continue

        if cmd_lower == 'check_gadgets':
            show_source_file("gadgets.txt", "GADGET REPOSITORY", Colors.CYAN)
            continue
        if cmd_lower == 'check_labels':
            show_source_file("labels.txt", "LABEL REPOSITORY", Colors.GREEN)
            continue
        if cmd_lower.startswith('check_files '):
            target_file = cmd[12:].strip()
            if target_file: check_files(target_file)
            else:
                print(f" {Colors.RED} ✖ Thiếu tên file!{Colors.RESET}")
                time.sleep(1)
            continue

        is_auto, target = False, cmd
        if cmd_lower.startswith("auto-compile "):
            is_auto, target = True, cmd[13:].strip()
        
        if not target.lower().endswith('.asm'): target += '.asm'
        path = os.path.join(rop_dir, target)

        if os.path.exists(path):
            if is_auto:
                last_mt = os.path.getmtime(path)
                compiler.compile(path)
                try:
                    while True:
                        time.sleep(1)
                        if os.path.getmtime(path) != last_mt:
                            last_mt = os.path.getmtime(path)
                            refresh_ui(rop_dir, compiler)
                            print(f" {Colors.YELLOW} [👀] MONITORING: {target} (Ctrl+C to stop){Colors.RESET}")
                            compiler.compile(path)
                except KeyboardInterrupt: pass
            else:
                compiler.compile(path)
                input(f"\n {Colors.WHITE} ❯ Press Enter to continue...")
        else:
            print(f" {Colors.RED} ✖ Error: File '{target}' not found! /Invalid UI Syntax"); time.sleep(1.5)

if __name__ == "__main__":
    main()